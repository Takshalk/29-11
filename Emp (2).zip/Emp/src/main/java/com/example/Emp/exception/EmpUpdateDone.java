package com.example.Emp.exception;

public class EmpUpdateDone extends RuntimeException{
	
	public EmpUpdateDone(String msg) {
		super(msg);
		
	}

}
