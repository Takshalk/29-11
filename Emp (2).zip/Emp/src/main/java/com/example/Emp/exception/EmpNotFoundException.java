package com.example.Emp.exception;

public class EmpNotFoundException extends RuntimeException{

		public EmpNotFoundException(String msg) {
			super(msg);
		}
}
